# 🛡️ EHS Assistant Chatbot

An AI-powered chatbot specialized in **Environment, Health & Safety** topics, built with Claude AI and deployable for free on Vercel.

---

## 📁 Project Structure

```
ehs-chatbot/
├── api/
│   └── chat.js          ← Backend (keeps your API key secret)
├── public/
│   └── index.html       ← Frontend (the chat UI)
├── vercel.json          ← Vercel deployment config
├── package.json
└── README.md
```

---

## 🚀 Deploy to Vercel (Free) — Step by Step

### Step 1 — Push to GitHub
1. Create a new repository on [github.com](https://github.com)
2. Upload all these files (keep the folder structure)
3. Commit and push

### Step 2 — Connect to Vercel
1. Go to [vercel.com](https://vercel.com) and sign up (free) with your GitHub account
2. Click **"Add New Project"**
3. Select your GitHub repository
4. Click **"Deploy"** — Vercel will auto-detect the config

### Step 3 — Add Your Anthropic API Key (IMPORTANT)
1. In your Vercel project dashboard, go to **Settings → Environment Variables**
2. Click **"Add New"**
3. Name: `ANTHROPIC_API_KEY`
4. Value: your API key (get it from [console.anthropic.com](https://console.anthropic.com))
5. Click **Save**
6. Go to **Deployments** and click **"Redeploy"** to apply the key

### Step 4 — Done! ✅
Your chatbot is live at `https://your-project-name.vercel.app`

---

## 🔑 Getting an Anthropic API Key
1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign up or log in
3. Go to **API Keys** → **Create Key**
4. Copy the key and paste it in Vercel (Step 3 above)

---

## 💡 Customizing the Topic
To change what topics the AI answers, edit the `SYSTEM_PROMPT` in `api/chat.js`.

---

## 🛡️ Security
- Your API key is stored in Vercel's environment variables — never exposed to users
- The backend (`api/chat.js`) acts as a secure proxy between the browser and Anthropic
