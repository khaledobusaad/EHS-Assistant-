export default async function handler(req, res) {
  // Allow requests from any origin (CORS)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid request body" });
  }

  const SYSTEM_PROMPT = `You are a specialized EHS (Environment, Health, and Safety) assistant. Your ONLY role is to answer questions related to:
- Environmental compliance and regulations (ISO 14001, EPA standards, waste management)
- Health and safety work instructions and manuals
- Workplace hazard identification and risk assessment
- Personal Protective Equipment (PPE) requirements and selection
- Safety procedures, emergency response, and evacuation plans
- Occupational health standards and monitoring
- Environmental waste management and disposal
- Safety Data Sheets (SDS/MSDS) interpretation
- OSHA, ISO 45001, ISO 14001, and related international standards
- Incident investigation, reporting, and root cause analysis
- Chemical safety and handling procedures
- Noise, radiation, ergonomic, and other workplace hazard controls
- Permit-to-work systems and job safety analysis (JSA)
- Fire safety and prevention
- Environmental impact assessments

If a user asks about ANYTHING outside these EHS topics, politely decline and remind them you are strictly an EHS assistant. Say something like: "I'm only able to help with Environment, Health & Safety topics. Please ask me an EHS-related question."

Format your answers clearly. Use bullet points or numbered lists when helpful. Be professional, accurate, and safety-focused. When relevant, cite applicable standards or regulations (e.g., OSHA 29 CFR 1910, ISO 45001:2018).`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1024,
        system: SYSTEM_PROMPT,
        messages,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({ error: data.error?.message || "API error" });
    }

    return res.status(200).json({ reply: data.content[0].text });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
}
